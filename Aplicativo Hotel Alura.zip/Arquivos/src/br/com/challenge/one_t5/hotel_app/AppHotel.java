package br.com.challenge.one_t5.hotel_app;

import br.com.challenge.one_t5.hotel_alura.view.GerenciadorJanelas;

/**
 * @author Alderson Santos
 *
 */
public class AppHotel {

	public static void main(String[] args) {

		new GerenciadorJanelas();

	}

}
